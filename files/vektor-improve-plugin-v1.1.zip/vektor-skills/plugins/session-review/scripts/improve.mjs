#!/usr/bin/env node
// Node.js >=20, built-in modules only. Never opens a network connection.
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

export const LIMITS = Object.freeze({ sessions: 100, files: 5000,
  totalBytes: 8 * 1024 * 1024 * 1024, lineBytes: 256 * 1024, events: 500, text: 4000, evidenceChars: 120000 });
const DAY = 86400000;
const SELECTION = 'Streaming sample balanced across recorded UTC user-message days, then round-robin across sessions (newest file modification time first within each day), then newest messages within each session/day. Day priority visits newest, oldest, then bisects gaps; caps can omit days. The bounded reservoir is rebalanced as rows arrive; discarded rows are not revisited. Files are scanned round-robin across modification-date buckets in the same spread order; copied/restored mtimes can change scan order. Final evidence is displayed newest first. Counts describe retained evidence only; scan/skip counters describe visited data.';
const REDACTED = '[REDACTED]';
const fail = message => { throw new Error(message); };
const hash = text => crypto.createHash('sha256').update(text).digest('hex');
export function mask(value) {
  return String(value)
    .replace(/\x1b\[[0-?]*[ -/]*[@-~]/g, '')
    .replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, '')
    .replace(/-----BEGIN [^-\r\n]*PRIVATE KEY-----[\s\S]*?(?:-----END [^-\r\n]*PRIVATE KEY-----|$)/g, REDACTED)
    .replace(/```(?:env|dotenv|\.env)\b[^\n]*\n[\s\S]*?(?:```|$)/gi, '[REDACTED ENV BLOCK]')
    // Conservative: any shell/.env assignment, even a harmless setting, loses its value.
    .replace(/^([ \t]*(?:export[ \t]+)?[A-Za-z_][\w.-]*[ \t]*=)[^\r\n]*/gm, '$1[REDACTED]')
    .replace(/\b([A-Za-z_][\w.-]*)\s*=\s*(?:"(?:\\.|[^"\\\r\n])*"|'(?:\\.|[^'\\\r\n])*'|[^\s,;`]+)/g, '$1=[REDACTED]')
    .replace(/(["']?[\w.-]*(?:api[_-]?key|token|secret|password|passwd|credential|authorization|cookie)[\w.-]*["']?\s*:\s*)(?:"(?:\\.|[^"\\\r\n])*"|'(?:\\.|[^'\\\r\n])*'|[^\s,;}]+)/gi, '$1[REDACTED]')
    .replace(/(["']?[A-Z][A-Z0-9_]{2,}["']?\s*:\s*)(?:"(?:\\.|[^"\\\r\n])*"|'(?:\\.|[^'\\\r\n])*'|[^\s,;}]+)/g, '$1[REDACTED]')
    .replace(/\b(?:Bearer|Basic)\s+[A-Za-z0-9+/_=.-]+/gi, REDACTED)
    .replace(/\b(?:sk[-_](?:ant[-_])?|pk[-_]live[-_]|gh[pousr]_|github_pat_|xox[baprs]-|AKIA|ASIA)[A-Za-z0-9_-]{8,}\b/g, REDACTED)
    .replace(/\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b/g, REDACTED)
    .replace(/https?:\/\/[^\s<>"'`]+/gi, match => match.includes('@') || match.includes('?') ? '[REDACTED URL]' : match)
    .replace(/\b[0-9a-f]{24,}\b/gi, REDACTED)
    .replace(/[A-Za-z0-9+/_-]{32,}={0,2}/g, REDACTED);
}
const clean = (value, max = LIMITS.text) => mask(value).slice(0, max);
const md = value => clean(value).replace(/[\\`*_{}\[\]()<>!|#]/g, '\\$&').replace(/\r?\n/g, ' ');
function integer(value, fallback, max) {
  if (value === undefined) return fallback;
  if (!/^\d+$/.test(String(value)) || Number(value) < 1 || Number(value) > max) fail('Invalid numeric bound.');
  return Number(value);
}
function time(value) {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})$/.test(value)) return null;
  const [year, month, day, hour, minute, second] = value.slice(0, 19).split(/[-T:]/).map(Number);
  if (month < 1 || month > 12 || day < 1 || day > new Date(Date.UTC(year, month, 0)).getUTCDate() || hour > 23 || minute > 59 || second > 59) return null;
  const parsed = Date.parse(value);
  return Number.isFinite(parsed) ? parsed : null;
}
function regular(target, kind = 'file') {
  const stat = fs.lstatSync(target);
  if (stat.isSymbolicLink() || (kind === 'file' ? !stat.isFile() : !stat.isDirectory())) fail('Symlinks and unexpected file types are not supported.');
  return stat;
}
// All output must be below the current workspace, never in a home/config path.
function withinWorkspace(target) {
  const base = fs.realpathSync(process.cwd());
  const full = path.resolve(target);
  const relative = path.relative(base, full);
  if (!relative || relative.startsWith('..') || path.isAbsolute(relative)) fail('Output must be inside the current workspace.');
  if (full.split(path.sep).some(part => ['.claude', '.codex', '.git', '.agents'].includes(part.toLowerCase()))) fail('Output cannot be a configuration directory.');
  let current = base;
  for (const part of relative.split(path.sep)) {
    if (['.claude', '.codex', '.git', '.agents'].includes(part.toLowerCase())) fail('Output cannot be a configuration directory.');
    current = path.join(current, part);
    if (fs.existsSync(current)) regular(current, 'directory');
  }
  return full;
}
function writeNew(target, text) { fs.writeFileSync(target, text, { flag: 'wx', mode: 0o600 }); }
const json = value => JSON.stringify(value, null, 2) + '\n';
function readJson(target) {
  if (regular(target).size > 16 * 1024 * 1024) fail('JSON input exceeds the size limit.');
  try { return JSON.parse(fs.readFileSync(target, 'utf8')); } catch { fail('Invalid JSON input.'); }
}
function textContent(row) {
  if (row.type !== 'user' || row.isMeta || row.isSidechain || row.isCompactSummary || row.message?.role !== 'user') return '';
  const content = row.message.content;
  if (typeof content === 'string') return content;
  if (Array.isArray(content)) return content.filter(item => item?.type === 'text' && typeof item.text === 'string').map(item => item.text).join('\n');
  return '';
}

// Visit the ends, then bisect the remaining intervals. If a cap is smaller than
// the number of days, the sample still reaches both ends instead of a recent prefix.
function spread(values) {
  if (values.length < 2) return values;
  const result = [values[0], values.at(-1)], queue = [[1, values.length - 2]];
  for (let index = 0; index < queue.length; index++) {
    const [lo, hi] = queue[index];
    if (lo > hi) continue;
    const mid = Math.floor((lo + hi) / 2);
    result.push(values[mid]);
    queue.push([lo, mid - 1], [mid + 1, hi]);
  }
  return result;
}

// The reservoir never holds more than the evidence budget plus one incoming
// message. Rebalance after each eligible row so later-scanned days get a turn.
function sample(pool, sessionCap, stats) {
  const buckets = new Map();
  for (const event of pool) {
    const day = event.date.slice(0, 10);
    if (!buckets.has(day)) buckets.set(day, new Map());
    const sessions = buckets.get(day);
    if (!sessions.has(event.session)) sessions.set(event.session, []);
    sessions.get(event.session).push(event);
  }
  const queues = spread([...buckets.keys()].sort().reverse()).map(day => {
    const sessions = [...buckets.get(day).values()].sort((a, b) => a[0].rank - b[0].rank);
    sessions.forEach(events => events.sort((a, b) => b.date.localeCompare(a.date) || a.key.localeCompare(b.key)));
    const queue = [];
    for (let index = 0; sessions.some(events => index < events.length); index++) {
      for (const events of sessions) if (events[index]) queue.push(events[index]);
    }
    return queue;
  });
  const retained = [], sessions = new Set();
  let chars = 0;
  for (let index = 0; queues.some(queue => index < queue.length); index++) {
    for (const queue of queues) {
      const event = queue[index];
      if (!event) continue;
      // Record each independently exceeded ceiling, even when another also rejects this row.
      const sessionFull = !sessions.has(event.session) && sessions.size >= sessionCap;
      const eventFull = retained.length >= LIMITS.events;
      const textFull = chars + event.text.length > LIMITS.evidenceChars;
      if (sessionFull) stats.sessionCapReached = true;
      if (eventFull) stats.eventCapReached = true;
      if (textFull) stats.textBudgetReached = true;
      if (sessionFull || eventFull || textFull) continue;
      retained.push(event);
      sessions.add(event.session);
      chars += event.text.length;
    }
  }
  return retained;
}

// Fixed chunks and a bounded line buffer, including for a huge unterminated line.
// Snapshot size excludes appends during this run; a partial final line at a scan
// ceiling is never parsed. No unbounded readline/string split allocations.
function scan(candidate, stats, scanBytes, visit) {
  let fd;
  try {
    regular(candidate.file);
    fd = fs.openSync(candidate.file, fs.constants.O_RDONLY | (fs.constants.O_NOFOLLOW ?? 0));
    const current = fs.fstatSync(fd);
    if (!current.isFile()) fail('Unexpected source type.');
    stats.filesRead++;
    const size = Math.min(candidate.size, current.size);
    const chunk = Buffer.alloc(64 * 1024), line = Buffer.alloc(LIMITS.lineBytes);
    let position = 0, length = 0, oversized = false;
    const finish = () => {
      if (!oversized && length) visit(line.subarray(0, length).toString('utf8'));
      length = 0; oversized = false;
    };
    while (position < size) {
      if (stats.bytesRead >= scanBytes) { stats.byteCapReached = true; return; }
      const count = fs.readSync(fd, chunk, 0, Math.min(chunk.length, size - position, scanBytes - stats.bytesRead), position);
      if (!count) break;
      position += count;
      stats.bytesRead += count;
      let start = 0;
      while (start < count) {
        const newline = chunk.indexOf(10, start);
        const end = newline >= 0 && newline < count ? newline : count;
        if (!oversized) {
          if (length + end - start > LIMITS.lineBytes) { oversized = true; stats.oversizedLines++; }
          else { chunk.copy(line, length, start, end); length += end - start; }
        }
        if (end < count) finish();
        start = end + 1;
      }
    }
    finish();
  } catch { stats.unreadableFiles++; }
  finally { if (fd !== undefined) fs.closeSync(fd); }
}

function coverageFor(events, window, stats) {
  const representedDates = [...new Set(events.map(event => event.date.slice(0, 10)))].sort();
  const represented = new Set(representedDates), unrepresentedDates = [];
  for (let date = Date.parse(window.from.slice(0, 10)); date <= Date.parse(window.to); date += DAY) {
    const day = new Date(date).toISOString().slice(0, 10);
    if (!represented.has(day)) unrepresentedDates.push(day);
  }
  return { representedDates, unrepresentedDates,
    scanComplete: !stats.byteCapReached && !stats.inventoryCapReached && stats.unreadableFiles === 0 && stats.skippedLinks === 0 };
}

export function collect(options = {}) {
  const now = options.now === undefined ? Date.now() : time(options.now);
  if (now === null) fail('Use an ISO timestamp with a timezone for --now.');
  const days = integer(options.days, 30, 3650);
  const sessionCap = integer(options['max-sessions'], LIMITS.sessions, 1000);
  const scanBytes = integer(options['max-scan-bytes'], LIMITS.totalBytes, LIMITS.totalBytes);
  const cutoff = now - days * DAY;
  const history = path.resolve(options.history ?? path.join(os.homedir(), '.claude', 'projects'));
  const output = withinWorkspace(options.out ?? path.join('.improve-output', `run-${new Date(now).toISOString().replaceAll(':', '-')}-${crypto.randomBytes(3).toString('hex')}`));
  if (fs.existsSync(output)) fail('Output already exists; choose a fresh run directory.');
  const stats = { candidateFiles: 0, filesRead: 0, sessionsAnalyzed: 0, userMessages: 0,
    malformedLines: 0, oversizedLines: 0, unsupportedUserRows: 0, invalidDates: 0,
    outsideWindow: 0, duplicateMessages: 0, oversizedFiles: 0, unreadableFiles: 0,
    skippedLinks: 0, bytesRead: 0, textTruncated: 0, sessionCapReached: false,
    byteCapReached: false, eventCapReached: false, textBudgetReached: false, inventoryCapReached: false, historyMissing: false };
  const candidates = [];
  if (!fs.existsSync(history)) stats.historyMissing = true;
  else {
    regular(history, 'directory');
    const projects = fs.readdirSync(history, { withFileTypes: true }).sort((a, b) => a.name.localeCompare(b.name));
    inventory: for (const project of projects) {
      if (project.isSymbolicLink()) { stats.skippedLinks++; continue; }
      if (!project.isDirectory()) continue;
      const dir = path.join(history, project.name);
      for (const entry of fs.readdirSync(dir, { withFileTypes: true }).sort((a, b) => a.name.localeCompare(b.name))) {
        if (entry.isSymbolicLink()) { stats.skippedLinks++; continue; }
        if (!entry.isFile() || !entry.name.endsWith('.jsonl')) continue;
        if (candidates.length >= LIMITS.files) { stats.inventoryCapReached = true; break inventory; }
        const file = path.join(dir, entry.name);
        const stat = regular(file);
        candidates.push({ file, project: project.name, size: stat.size, mtime: stat.mtimeMs });
      }
    }
  }
  candidates.sort((a, b) => b.mtime - a.mtime || a.file.localeCompare(b.file));
  stats.candidateFiles = candidates.length;
  let events = [];
  const projectAliases = new Map(), seen = new Set();
  candidates.forEach((candidate, rank) => { candidate.rank = rank; });
  // Round-robin file visits across mtime days as a best effort if scanning itself
  // stops. Actual retained-day balancing below uses recorded user timestamps.
  const fileDays = new Map();
  for (const candidate of candidates) {
    const day = new Date(candidate.mtime).toISOString().slice(0, 10);
    if (!fileDays.has(day)) fileDays.set(day, []);
    fileDays.get(day).push(candidate);
  }
  const fileQueues = spread([...fileDays.keys()].sort().reverse()).map(day => fileDays.get(day));
  const visits = [];
  for (let index = 0; fileQueues.some(queue => index < queue.length); index++) {
    for (const queue of fileQueues) if (queue[index]) visits.push(queue[index]);
  }
  for (const candidate of visits) {
    if (stats.bytesRead >= scanBytes && candidate.size > 0) { stats.byteCapReached = true; break; }
    const session = `s${String(candidate.rank + 1).padStart(3, '0')}`;
    if (!projectAliases.has(candidate.project)) projectAliases.set(candidate.project, `project-${projectAliases.size + 1}`);
    scan(candidate, stats, scanBytes, line => {
      if (!line.trim()) return;
      let row;
      try { row = JSON.parse(line); } catch { stats.malformedLines++; return; }
      if (!row || typeof row !== 'object') { stats.malformedLines++; return; }
      const text = textContent(row);
      if (!text) { if (row.type === 'user') stats.unsupportedUserRows++; return; }
      const timestamp = time(row.timestamp);
      if (timestamp === null) { stats.invalidDates++; return; }
      if (timestamp < cutoff || timestamp > now) { stats.outsideWindow++; return; }
      // UUIDs remove resumed/forked copies. Without a UUID, only exact same-session copies merge.
      const key = typeof row.uuid === 'string' && row.uuid ? hash(row.uuid) : hash(`${candidate.file}\0${row.timestamp}\0${text}`);
      if (seen.has(key)) { stats.duplicateMessages++; return; }
      seen.add(key);
      const masked = mask(text);
      if (masked.length > LIMITS.text) stats.textTruncated++;
      events.push({ session, project: projectAliases.get(candidate.project), key, rank: candidate.rank,
        date: new Date(timestamp).toISOString(), text: masked.slice(0, LIMITS.text), truncated: masked.length > LIMITS.text });
      events = sample(events, sessionCap, stats);
    });
    if (stats.byteCapReached) break;
  }
  events.sort((a, b) => b.date.localeCompare(a.date) || a.session.localeCompare(b.session));
  events = events.map(({ key, rank, ...event }, index) => ({ ...event, id: `e${String(index + 1).padStart(4, '0')}` }));
  stats.userMessages = events.length;
  stats.sessionsAnalyzed = new Set(events.map(event => event.session)).size;
  const evidence = { schemaVersion: 1, generatedAt: new Date(now).toISOString(),
    window: { days, from: new Date(cutoff).toISOString(), to: new Date(now).toISOString(), sessionCap, scanBytes },
    range: { first: events.at(-1)?.date ?? null, last: events[0]?.date ?? null },
    selection: SELECTION,
    stats, events };
  evidence.coverage = coverageFor(events, evidence.window, stats);
  fs.mkdirSync(output, { recursive: true, mode: 0o700 });
  writeNew(path.join(output, 'evidence.json'), json(evidence));
  writeNew(path.join(output, 'findings.example.json'), json({ schemaVersion: 1, wrongs: [], skills: [], rules: [] }));
  return { run: path.relative(process.cwd(), output), stats, range: evidence.range };
}

function string(value, label, max) {
  if (typeof value !== 'string' || !value.trim() || value.length > max) fail(`Invalid ${label}.`);
  return clean(value, max);
}
function validateEvidence(evidence) {
  if (evidence.schemaVersion !== 1 || !Array.isArray(evidence.events) || evidence.events.length > LIMITS.events ||
      !evidence.stats || !evidence.window || time(evidence.generatedAt) === null) fail('Invalid evidence bundle.');
  const numberStats = ['candidateFiles', 'filesRead', 'sessionsAnalyzed', 'userMessages', 'malformedLines',
    'oversizedLines', 'unsupportedUserRows', 'invalidDates', 'outsideWindow', 'duplicateMessages',
    'oversizedFiles', 'unreadableFiles', 'skippedLinks', 'bytesRead', 'textTruncated'];
  const booleanStats = ['sessionCapReached', 'byteCapReached', 'eventCapReached', 'textBudgetReached', 'inventoryCapReached', 'historyMissing'];
  if (Object.keys(evidence.stats).length !== numberStats.length + booleanStats.length ||
      numberStats.some(key => !Number.isSafeInteger(evidence.stats[key]) || evidence.stats[key] < 0) ||
      booleanStats.some(key => typeof evidence.stats[key] !== 'boolean')) fail('Invalid coverage metadata.');
  if (time(evidence.window.from) === null || time(evidence.window.to) === null ||
      !Number.isSafeInteger(evidence.window.days) || evidence.window.days < 1 || evidence.window.days > 3650 ||
      !Number.isSafeInteger(evidence.window.sessionCap) || evidence.window.sessionCap < 1 || evidence.window.sessionCap > 1000 ||
      !Number.isSafeInteger(evidence.window.scanBytes) || evidence.window.scanBytes < 1 || evidence.window.scanBytes > LIMITS.totalBytes ||
      time(evidence.window.from) !== time(evidence.window.to) - evidence.window.days * DAY ||
      evidence.generatedAt !== evidence.window.to) fail('Invalid sample window.');
  const events = new Map();
  for (const event of evidence.events) {
    if (!/^e\d{4}$/.test(event.id) || events.has(event.id) || !/^s\d{3,4}$/.test(event.session) ||
        !/^project-\d+$/.test(event.project) || time(event.date) === null || typeof event.text !== 'string' || event.text.length > LIMITS.text) fail('Invalid evidence event.');
    if (event.date !== new Date(time(event.date)).toISOString()) fail('Event dates must use canonical UTC timestamps.');
    if (time(event.date) < time(evidence.window.from) || time(event.date) > time(evidence.window.to)) fail('Event is outside the sample window.');
    events.set(event.id, { ...event, text: clean(event.text) });
  }
  if (evidence.stats.userMessages !== events.size || evidence.stats.sessionsAnalyzed !== new Set([...events.values()].map(e => e.session)).size) fail('Evidence counts do not match events.');
  if ([...events.values()].reduce((sum, event) => sum + event.text.length, 0) > LIMITS.evidenceChars) fail('Evidence exceeds the text budget.');
  const dates = [...events.values()].map(event => event.date).sort();
  if (evidence.range?.first !== (dates[0] ?? null) || evidence.range?.last !== (dates.at(-1) ?? null) ||
      evidence.stats.filesRead < evidence.stats.sessionsAnalyzed || evidence.stats.sessionsAnalyzed > evidence.window.sessionCap ||
      evidence.stats.filesRead > evidence.stats.candidateFiles) fail('Invalid sample coverage.');
  if (JSON.stringify(evidence.coverage) !== JSON.stringify(coverageFor(evidence.events, evidence.window, evidence.stats))) fail('Invalid coverage dates.');
  return events;
}
export function validateFindings(findings, evidence) {
  const events = validateEvidence(evidence);
  if (findings.schemaVersion !== 1) fail('Invalid findings schema.');
  const groups = {};
  for (const category of ['wrongs', 'skills', 'rules']) {
    const items = findings[category];
    if (!Array.isArray(items) || items.length > 20) fail('Invalid findings category.');
    const seenSets = new Set();
    groups[category] = items.map(item => {
      const title = string(item.title, 'finding title', 160);
      const reason = string(item.reason, 'finding reason', 600);
      if (!Array.isArray(item.evidence) || item.evidence.length === 0 || item.evidence.some(id => !events.has(id))) fail('Finding cites missing evidence.');
      const ids = [...new Set(item.evidence)];
      if (ids.length !== item.evidence.length) fail('Duplicate evidence IDs would inflate a count.');
      const setKey = ids.slice().sort().join(',');
      if (seenSets.has(setKey)) fail('Duplicate findings in the same section.');
      seenSets.add(setKey);
      const refs = ids.map(id => events.get(id)).sort((a, b) => b.date.localeCompare(a.date));
      if (item.quotes !== undefined && (!item.quotes || typeof item.quotes !== 'object' || Array.isArray(item.quotes))) fail('Invalid quotes map.');
      const quotes = {};
      for (const [id, quote] of Object.entries(item.quotes ?? {})) {
        if (!ids.includes(id) || typeof quote !== 'string' || !quote.trim() || quote.length > 240 || !events.get(id).text.includes(quote)) fail('Quote must be a short exact substring of cited evidence.');
        quotes[id] = quote;
      }
      const sessions = new Set(refs.map(e => e.session)).size;
      if (category === 'wrongs' && ids.length < 2) fail('Repeated corrections need multiple user messages.');
      if (category === 'skills') {
        if (!['routine', 'reexplained-task'].includes(item.kind)) fail('Invalid skill opportunity kind.');
        if (item.kind === 'routine' && ids.length < 3) fail('A routine needs more than two supporting occurrences.');
        if (item.kind === 'reexplained-task' && sessions < 2) fail('A re-explained task needs separate sessions.');
      }
      let draft;
      if (category === 'skills') {
        if (!item.draft || !/^[a-z][a-z0-9-]{0,63}$/.test(item.draft.name)) fail('Invalid draft name.');
        const name = item.draft.name;
        if (/^(con|prn|aux|nul|com[0-9]|lpt[0-9])$/i.test(name)) fail('Reserved draft name.');
        if (mask(name) !== name) fail('Draft name resembles a secret; choose a short descriptive name.');
        draft = { name, description: string(item.draft.description, 'draft description', 600),
          instructions: string(item.draft.instructions, 'draft instructions', 12000) };
      }
      return { title, reason, refs, quotes, count: ids.length, sessions, kind: item.kind,
        ...(category === 'rules' ? { line: string(item.line, 'proposed rule', 600), scope: string(item.scope, 'rule scope', 160) } : {}),
        ...(draft ? { draft } : {}) };
    }).sort((a, b) => b.count - a.count || b.sessions - a.sessions || a.title.localeCompare(b.title));
  }
  const names = groups.skills.slice(0, 3).map(item => item.draft.name);
  if (new Set(names).size !== names.length) fail('Top draft names must be unique.');
  return groups;
}

function report(evidence, groups) {
  const { stats, window, range } = evidence;
  const reasons = [];
  if (stats.byteCapReached) reasons.push('the scan safety limit stopped reading history');
  if (stats.inventoryCapReached) reasons.push('the file inventory safety limit left files unvisited');
  if (stats.sessionCapReached) reasons.push('the retained-session limit left some sessions out');
  if (stats.eventCapReached) reasons.push('the retained-message limit left some messages out');
  if (stats.textBudgetReached) reasons.push('the retained-text limit left some messages out');
  if (stats.historyMissing) reasons.push('the history folder was missing');
  if (stats.oversizedLines || stats.unreadableFiles || stats.skippedLinks || stats.malformedLines || stats.invalidDates || stats.unsupportedUserRows) reasons.push('some source data could not be used');
  const shorter = range.first !== window.from || range.last !== window.to;
  const explanation = shorter
    ? `; the sample is shorter than the requested window because ${reasons.length ? reasons.join('; ') + '; the remaining usable messages do not reach both requested boundaries' : 'the available eligible user messages do not reach both requested boundaries'}.`
    : '; the retained messages reach both requested boundaries, which does not mean every session or message was included.';
  const rows = ['# Session improvement report', '',
    `Observed user-message range: ${range.first ?? 'none'} through ${range.last ?? 'none'}${explanation}`, '',
    `Generated: ${evidence.generatedAt}. Source: masked local evidence.json.`, '',
    `Read ${stats.filesRead} session files; analyzed ${stats.sessionsAnalyzed} sessions containing ${stats.userMessages} eligible user messages.`,
    `Requested window: ${window.from} through ${window.to} (inclusive); retained-session cap: ${window.sessionCap}.`,
    `Scan safety ceiling: ${window.scanBytes} bytes; retained evidence ceilings: ${LIMITS.events} messages and ${LIMITS.evidenceChars} text characters; per-message text: ${LIMITS.text} characters; per-line scan limit: ${LIMITS.lineBytes} bytes.`,
    `Dates not covered by retained user messages (UTC): ${evidence.coverage.unrepresentedDates.join(', ') || 'none'}.`,
    evidence.coverage.scanComplete
      ? 'All inventoried regular files were scanned; dates without retained evidence may reflect no eligible messages, skipped rows, or sampling limits, not inactivity.'
      : 'History scanning was incomplete: unvisited data may belong to any requested date, including dates already represented; the dates above are unrepresented, not proof that no history exists.',
    SELECTION, '',
    'Repeat counts = distinct cited user messages, not independently verified task executions. Session counts = source files after duplicate-message removal. Model-selected groupings are judgments; the helper calculates their counts and quotes.', '',
    `Coverage: ${json(stats).trim().replaceAll('\n', ' ')}`, '',
    'Only user text is analyzed. Tool outputs, assistant replies, nested subagent logs, metadata and compaction summaries are excluded. Skips, caps and truncation can hide evidence; absence of a finding is not proof of absence.', '',
    'Privacy: the helper has no network calls. Masked evidence is processed in your normal Claude Code conversation; Claude service processing and plan usage still apply. Redaction is conservative pattern matching, not a guarantee that every secret or personal detail is removed. Review before sharing.', '',
    'Retention: Claude Code deletes older sessions according to cleanupPeriodDays (default 30 days). To keep more future history, manually merge "cleanupPeriodDays": 90 into ~/.claude/settings.json. Keep other settings intact. This tool never changes it and cannot restore deleted sessions.', ''];
  for (const [key, heading] of [['wrongs', 'what keeps going wrong'], ['skills', 'skills you are missing'], ['rules', 'lines to add to CLAUDE.md']]) {
    rows.push(`## ${heading}`, '');
    if (!groups[key].length) rows.push('No supported finding in this sample.', '');
    for (const item of groups[key]) {
      rows.push(`### ${md(item.title)} — ${item.count} messages / ${item.sessions} sessions`, '', md(item.reason), '');
      if (key === 'skills') rows.push(`Type: ${md(item.kind)}. Candidate missing skill; installed-skill coverage must be checked by Claude.`, '');
      if (key === 'rules') rows.push(`Proposed line (${md(item.scope)}): ${md(item.line)}`, '');
      for (const ref of item.refs.slice(0, 3)) {
        const quote = item.quotes[ref.id] ?? ref.text.slice(0, 240);
        rows.push(`- ${ref.date} · ${ref.session} · ${ref.project} · ${ref.id}: “${md(quote)}${!item.quotes[ref.id] && ref.text.length > 240 ? '…' : ''}”`);
      }
      rows.push(`Evidence IDs: ${item.refs.map(ref => ref.id).join(', ')}.`, '');
    }
  }
  rows.push('## Staged drafts', '', ...(groups.skills.length ? groups.skills.slice(0, 3).map(item => `- STAGING/${item.draft.name}/SKILL.md`) : ['None: insufficient supported opportunities.']), '',
    'Drafts are inert review files. No skills were installed; no settings or CLAUDE.md files were edited. Approve a specific file and destination before any later installation.', '');
  return rows.join('\n');
}
export function render(options = {}) {
  if (!options.run) fail('render requires --run.');
  const run = withinWorkspace(options.run);
  regular(run, 'directory');
  const evidence = readJson(path.join(run, 'evidence.json'));
  const findings = readJson(path.join(run, 'findings.json'));
  const groups = validateFindings(findings, evidence);
  const staging = path.join(run, 'STAGING');
  if (fs.existsSync(staging) || fs.existsSync(path.join(run, 'report.md'))) fail('Report or staging already exists; use a fresh run to avoid overwriting reviews.');
  const reportText = report(evidence, groups);
  fs.mkdirSync(staging, { mode: 0o700 });
  for (const item of groups.skills.slice(0, 3)) {
    const draft = item.draft;
    const directory = path.join(staging, draft.name);
    fs.mkdirSync(directory, { mode: 0o700 });
    writeNew(path.join(directory, 'SKILL.md'), `---\nname: ${draft.name}\ndescription: ${JSON.stringify(draft.description)}\n---\n\n# Review draft: ${draft.name}\n\nNot installed. Review scope, tools and permissions before use.\n\n${draft.instructions}\n\n<!-- Evidence: ${item.refs.map(ref => ref.id).join(', ')}; ${item.count} distinct cited messages. -->\n`);
  }
  writeNew(path.join(run, 'report.md'), reportText);
  return { report: path.relative(process.cwd(), path.join(run, 'report.md')), drafts: groups.skills.slice(0, 3).map(item => item.draft.name) };
}

export function main(args) {
  const [command, ...rest] = args;
  if (!['collect', 'render'].includes(command)) fail('Usage: node improve.mjs collect [--history PATH --out PATH --days N --max-sessions N --max-scan-bytes N --now ISO] | render --run PATH');
  const allowed = command === 'collect' ? ['history', 'out', 'days', 'max-sessions', 'max-scan-bytes', 'now'] : ['run'];
  const options = {};
  for (let i = 0; i < rest.length; i += 2) {
    const key = rest[i].slice(2);
    if (!rest[i].startsWith('--') || !allowed.includes(key) || rest[i + 1] === undefined || options[key] !== undefined) fail('Invalid command arguments.');
    options[key] = rest[i + 1];
  }
  return command === 'collect' ? collect(options) : render(options);
}
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  try { console.log(json(main(process.argv.slice(2)))); }
  catch (error) {
    // OS/JSON errors may contain source paths or raw values: do not echo them.
    console.error(error.code || error instanceof SyntaxError ? 'Local I/O or JSON validation failed; no raw details printed.' : clean(error.message, 300));
    process.exitCode = 1;
  }
}
