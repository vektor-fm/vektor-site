# Findings contract (schema version 1)

Create `findings.json` in the run folder. Use only IDs in `evidence.json`. Arrays may be empty; do not make a draft just to reach a quota. Each section is independently sorted by the helper's count of unique cited user messages (then session count, then title).

```json
{
  "schemaVersion": 1,
  "wrongs": [
    {
      "title": "Use the requested output format",
      "reason": "The user corrects the same format more than once. This is a sample-level pattern, not a proven cause.",
      "evidence": ["e0001", "e0002"],
      "quotes": {"e0001": "A verbatim substring copied from this masked event"}
    }
  ],
  "skills": [
    {
      "title": "Prepare a release checklist",
      "reason": "The recurring procedure is described in separate requests. Completion and installed-skill coverage remain unverified.",
      "kind": "routine",
      "evidence": ["e0001", "e0002", "e0003"],
      "draft": {
        "name": "prepare-release-checklist",
        "description": "Prepare a release checklist when the user requests release preparation.",
        "instructions": "State required inputs. Follow the evidence-supported steps. Verify the result. Stop at the user's approval boundary."
      }
    }
  ],
  "rules": [
    {
      "title": "Preserve output format",
      "reason": "A candidate rule from explicit feedback; compare with existing project instructions before adding.",
      "evidence": ["e0001"],
      "scope": "This project only",
      "line": "Use the output format requested in the current task."
    }
  ]
}
```

The sample is a shape example; its IDs and quotes must be replaced with actual evidence. Never insert fabricated counts, dates or quotes. The helper supplies those from the collected bundle.

- `wrongs`: at least two unique supporting message IDs per finding. Separate sessions are not required; the session count is shown separately.
- `skills`: select the strongest one to three, or none. `kind: "routine"` requires at least three message IDs documenting occurrences of the same manual multi-step procedure. `kind: "reexplained-task"` requires at least two distinct sessions. Evidence thresholds alone do not prove a good skill opportunity: model judgment is still required.
- Each skill needs a draft. Slugs use lowercase letters, digits and hyphens, start with a letter, and have at most 64 characters. No paths, dots or Windows device names. `instructions` is Markdown without YAML frontmatter; the helper adds frontmatter and a review notice. Draft descriptions are quoted as YAML strings.
- `rules`: at least one supporting message, plus `scope` and the exact proposed `line`.
- Optional `quotes`: map cited IDs to exact, contiguous, nonempty substrings (up to 240 characters) of those events. If omitted, the helper quotes the start of the message. It renders up to three quotes per finding and lists all IDs for audit.
- Titles: up to 160 characters. Reasons, rule lines and draft descriptions: up to 600. Rule scope: up to 160. Draft instructions: up to 12,000. At most 20 findings per section; the normal skill workflow should produce a short report.

Duplicate evidence within a finding and identical evidence sets within a section are rejected. The same message may support a correction, a rule and a skill; those are different sections, not additive occurrence totals. Exact grouping remains a model judgment. The helper does not execute drafts or validate their domain-specific procedure.
