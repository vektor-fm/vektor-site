// Generated packaging has one editable identity source. No dependencies or network.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const config = JSON.parse(fs.readFileSync(path.join(root, 'identity.json'), 'utf8'));
const { repository, plugin, skill, license } = config;
if (!/^[a-z0-9-]+\/[a-z0-9-]+$/.test(repository) ||
    ![plugin, skill].every(s => /^[a-z][a-z0-9-]{0,63}$/.test(s)) || license !== 'MIT') {
  throw new Error('Invalid identity; license changes require a matching LICENSE text.');
}
const marketplace = repository.split('/')[1];
const json = value => JSON.stringify(value, null, 2) + '\n';
const outputs = new Map([
  ['.claude-plugin/marketplace.json', json({
    name: marketplace, owner: { name: repository.split('/')[0] },
    plugins: [{ name: plugin, source: './plugins/session-review',
      description: 'Review local Claude Code history and stage evidence-backed improvement drafts.',
      version: '0.1.0', license }]
  })],
  ['plugins/session-review/.claude-plugin/plugin.json', json({
    name: plugin, version: '0.1.0',
    description: 'Review local session history; stage skills and project rules for approval.',
    license
  })],
  [`plugins/session-review/skills/${skill}/SKILL.md`, fs.readFileSync(path.join(root, 'templates/SKILL.md'), 'utf8').replaceAll('{{SKILL}}', skill)],
  ['README.md', fs.readFileSync(path.join(root, 'templates/README.md'), 'utf8')
    .replaceAll('{{REPOSITORY}}', repository).replaceAll('{{PLUGIN}}', plugin)
    .replaceAll('{{SKILL}}', skill).replaceAll('{{MARKETPLACE}}', marketplace)
    .replaceAll('{{LICENSE}}', license)]
]);
let mismatch = false;
for (const [relative, contents] of outputs) {
  const target = path.join(root, relative);
  if (process.argv.includes('--check')) {
    if (!fs.existsSync(target) || fs.readFileSync(target, 'utf8') !== contents) {
      console.error(`Generated file differs: ${relative}`); mismatch = true;
    }
  } else {
    fs.mkdirSync(path.dirname(target), { recursive: true });
    fs.writeFileSync(target, contents);
  }
}
// A command rename must not leave a second discoverable skill.
const skillsRoot = path.join(root, 'plugins/session-review/skills');
if (fs.existsSync(skillsRoot)) {
  for (const entry of fs.readdirSync(skillsRoot)) {
    if (entry !== skill) {
      const stale = path.join(skillsRoot, entry, 'SKILL.md');
      if (fs.existsSync(stale) && fs.readFileSync(stale, 'utf8').includes('GENERATED from templates/SKILL.md')) {
        if (process.argv.includes('--check')) mismatch = true;
        else fs.unlinkSync(stale);
      }
    }
  }
}
if (mismatch) process.exitCode = 1;
