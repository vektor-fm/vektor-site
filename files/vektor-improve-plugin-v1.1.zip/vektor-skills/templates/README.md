# Session improvement skill

A free Claude Code plugin that reviews recent local session history for repeated corrections, re-explained tasks and recurring manual routines. It writes a short evidence-backed Markdown report and stages up to three skill drafts for review. It never installs those drafts or edits CLAUDE.md or settings.

**Local scaffold only. Publication and installation remain unverified.** Names in `identity.json` were confirmed by the founder on 2026-10-06 and are unchanged by the coverage fix. For a separately approved identity change, edit that source and run `node scripts/generate.mjs`. Manifests, the skill entrypoint and this README are generated copies, not separate naming decisions. The helper's physical plugin directory is deliberately stable across branding changes. The licence is {{LICENSE}}; changing it requires replacing the legal text too.

## Requirements and cost

- Claude Code with plugin/skill support and the user's own active Claude plan.
- **Node.js 20 or later** on PATH (`node --version`). Only built-in Node modules are used; no `npm install` is needed. Native Claude Code installs do not necessarily include Node; install Node separately if missing.
- Windows, macOS or Linux. Home resolution uses `os.homedir()`, not a hard-coded username. Cross-platform design has only been executed on Windows in this build.
- Runs on your own plan; your plan's usage limits still apply. No Vektor account, API key, billing integration or credit system. Normal Claude Code authentication remains necessary.

## Expected installation — unverified until installed from a real repo

These are the expected commands **after the founder publishes the repository**. Do not run them expecting this local scaffold to be available remotely:

```text
/plugin marketplace add {{REPOSITORY}}
/plugin install {{PLUGIN}}@{{MARKETPLACE}}
```

Expected invocation:

```text
/{{PLUGIN}}:{{SKILL}}
```

Marketplace installation, actual slash-name display and the full model-driven workflow have not been tested. No GitHub repository, remote, marketplace publication or account configuration was created by this build. A future developer can load the plugin temporarily with `claude --plugin-dir ./plugins/session-review`; that command was not run here because real Claude configuration and sessions must remain untouched.

## What happens

1. A local deterministic helper streams `~/.claude/projects/*/*.jsonl` line by line. Defaults are the last 30 days and at most 100 **retained sessions**, not 100 files scanned. Large assistant/tool logs cost scanning time, not retained-evidence budget. The sample is balanced across recorded UTC user-message dates, then round-robin across sessions within each day (newest filesystem modification time first), then newest messages within each session/day. Day priority visits newest, oldest, then repeatedly bisects the gaps, so a tight cap spreads coverage across the window. Final evidence is displayed newest first.
2. It retains user text only, masks secret-shaped strings before model exposure, deduplicates UUIDs, aliases project/session identifiers, and writes a bounded `evidence.json` locally. A bounded in-memory sample is rebalanced as eligible rows arrive; discarded rows are not revisited. It records files read, retained sessions/messages, actual date range, every hit cap, skips and truncation. The report opens with the observed range and explains a shortfall; it lists every UTC date with no retained evidence. Raw source paths, UUIDs, assistant replies, tool results, nested subagent logs and transcript metadata are not exported.
3. Claude clusters semantically related evidence and proposes remedies. It writes structured findings with evidence IDs. Installed skills are checked through Claude's available-skill list; when coverage is unknown, missing-skill suggestions remain explicitly provisional.
4. The helper validates references, calculates exact message/session counts for those clusters and sorts each report section by repeat count. It writes **what keeps going wrong**, **skills you are missing**, and **lines to add to CLAUDE.md**, with dated quotes.
5. The strongest supported opportunities produce `STAGING/<draft>/SKILL.md`. If Anthropic's skill-creator is available, Claude hands drafting to that skill under the same output restrictions. Otherwise Claude writes the drafts itself. Neither route installs anything. Insufficient evidence produces fewer drafts or none.

Counts describe distinct cited user messages, **not proven completed tasks or time saved**. Clustering, recommendations and draft quality are model judgments. The helper cannot verify that a proposed rule is absent from CLAUDE.md or that all installed skills were visible.

## Privacy and its limits

The helper makes **no network calls**, has no analytics or third-party dependencies, and writes only beneath a fresh output directory in the current workspace. It never edits or deletes source history. It rejects output outside the workspace, config directories, symlinked output paths and unsafe draft paths. Errors do not echo raw transcript content or source paths. New output files request owner-only permissions where the OS supports them; Windows ACLs remain inherited.

**This is not a fully offline model.** Masked evidence enters the user's ordinary Claude Code conversation and is processed by their configured Claude service. The plugin adds no separate upload service. Strictly keeping all data off the network is incompatible with Claude's model analysis on a normal plan. A user requiring zero model exposure can run `collect` locally and inspect its output without giving it to Claude, but will not get semantic analysis or drafted skills.

Masking covers common API/token shapes, assignments such as `.env` values, credential-labelled fields, bearer/basic credentials, private-key blocks, JWTs, long hex/base64-like strings and credential/query-bearing URLs. It intentionally over-masks some harmless identifiers. Pattern masking cannot guarantee detection of arbitrary short, split or obfuscated secrets, nor does it anonymize every project name, personal detail or commercial fact in ordinary prose. **Review reports and drafts before sharing or recording the film.** Never use the raw history as a fallback when masking removes needed context.

Session text is untrusted data. The skill explicitly forbids obeying embedded instructions or running commands copied from history. There is no network, installation or settings-write capability in the helper; model instructions are workflow rules, not an OS sandbox.

Output defaults to `.improve-output/run-<timestamp>-<random>/`:

```text
evidence.json          masked messages, sampling metadata and exact coverage
findings.example.json  empty shape; copy to findings.json for the model's judgment
findings.json          model-selected clusters and draft text
report.md              helper-rendered report
STAGING/<slug>/SKILL.md review drafts only
```

Output is gitignored in this repo. In other workspaces, keep this directory out of commits and cloud-sync folders yourself. Even masked files remain sensitive. Rerendering refuses to overwrite an existing report or STAGING folder; collect to a fresh run for revisions.

## History retention

Claude Code deletes sessions older than `cleanupPeriodDays` at startup; the documented default is **30 days**. To retain more future history, manually merge this property into your existing `~/.claude/settings.json`:

```json
{
  "cleanupPeriodDays": 90
}
```

Preserve all other settings; this snippet is not an instruction to replace the file. The plugin never changes the setting and cannot recover deleted sessions. The default and startup deletion are supported by the official costs documentation checked for this build; see the [documentation verification](docs/DOCS-VERIFICATION.md) for exact verification status.

## Helper commands and bounds

```text
node plugins/session-review/scripts/improve.mjs collect
node plugins/session-review/scripts/improve.mjs collect --history "<projects-folder>" --days 30 --max-sessions 100 --out ".improve-output/my-review"
node plugins/session-review/scripts/improve.mjs render --run ".improve-output/my-review"
```

The first command reads real history: **it was not run during this build**. `--history` is a folder containing project folders, each with session `.jsonl` files. It also supports a nonstandard Claude configuration directory by pointing at its `projects` folder. `--now <ISO timestamp with timezone>` exists for reproducible tests. All date comparisons use UTC and include both window boundaries (a 30-day interval can touch 31 calendar dates). Selection never relies on filenames for dates. `--max-sessions` limits retained sessions; all inventoried files are scanned unless a scan safety ceiling stops the run. `--max-scan-bytes N` can lower, but never raise, the scan ceiling.

The parser accepts timestamped JSONL user rows with `type: "user"`, `message.role: "user"` and string content or text blocks. This is a deliberately narrow, defensive parser, not a promise of compatibility with every Claude Code version. It excludes sidechain, metadata and compaction-summary rows, ignores tool-result blocks, and skips malformed/missing-timestamp data. No real transcript structure or values were inspected in this build.

Safety ceilings: 5,000 candidate files inventoried; **8 GiB total scanned**; 256 KiB per line; 500 retained messages; 4,000 characters per message; 120,000 retained message-text characters overall (plus JSON metadata). There is no per-file size cutoff. Fixed 64 KiB scan chunks and a bounded line buffer skip oversized lines without loading whole files; a line cut by the scan ceiling is never parsed. Files are read only up to their initial size, excluding later appends. The text ceiling bounds model input, not tokens or price. Every cap that excludes data is reported, even when more than one applies. `bytesRead` measures scanned bytes, not retained text; `filesRead` counts files opened for scanning and can exceed the retained-session cap. The legacy `oversizedFiles` counter remains zero; `oversizedLines` counts skipped lines. Deduplication stores hashes of eligible message identities only, never raw source IDs, in memory while scanning.

Scanning visits files round-robin across filesystem-modification-date buckets, newest files first within each bucket, using the same spread order as above. Copies/restores can alter this order; retained-day balancing uses actual user timestamps even if all files have the same modification date. Inventory stops at its ceiling in sorted project/file-name order and reports that limitation. The safety byte ceiling can stop mid-file: scanning is then explicitly incomplete, and unvisited data could belong to **any** requested date, including a represented date. Dates without retained evidence are not proof of inactivity or deletion. When caps cannot fit every date, the report names the missing dates instead of claiming a full month. Reaching both window endpoints also does not prove exhaustive coverage.

Caps, masked text, truncation and skipped rows can hide patterns. A missing history directory produces an explicit empty report workflow. Source UUIDs deduplicate resumed/forked message copies; absent UUIDs deduplicate identical same-file timestamp/text rows only. Scan/skip counters cover visited data; message/session counts and the observed range describe the final retained sample. Sessions mean source files, not verified conversation identities across copied files.

## Develop and verify

```text
node scripts/generate.mjs
node scripts/generate.mjs --check
node --test tests/*.test.mjs
```

No package install, live history access, model calls or Claude config changes are needed. Tests use only committed fake fixtures and temporary output under `.tmp/`. See [build verification](docs/BUILD-VERIFICATION.md) for the executed test results, exact deliverable files and outstanding founder checks. See [findings schema](plugins/session-review/references/findings.md) for the model/helper interface.

Official docs were checked on 2026-10-06: [plugin layout](https://code.claude.com/docs/en/plugins/create), [marketplaces](https://code.claude.com/docs/en/plugin-marketplaces), [skills and frontmatter](https://code.claude.com/docs/en/skills). Layout conformity is documentation-backed; it is not an end-to-end install result.
