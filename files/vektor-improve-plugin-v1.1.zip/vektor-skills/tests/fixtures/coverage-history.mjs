import fs from 'node:fs';
import path from 'node:path';

const DAY = 86_400_000;
const NOW = Date.parse('2026-10-06T12:00:00Z');

/**
 * Create a deterministic, synthetic history for coverage tests.  The newest
 * sessions deliberately contain large assistant/tool rows; those rows must
 * not consume the retained-user-message budget.
 */
export function createCoverageHistory(root, options = {}) {
  const days = options.days ?? 30;
  const largeSessions = options.largeSessions ?? 5;
  const fillerLines = options.fillerLines ?? 170;
  const fillerBytes = options.fillerBytes ?? 100 * 1024;
  const messagesPerSession = options.messagesPerSession ?? 1;
  const sessionsPerDay = options.sessionsPerDay ?? 1;
  const longUserText = options.longUserText ?? false;
  const includeSecret = options.includeSecret ?? false;
  const project = path.join(root, 'coverage-project');
  fs.mkdirSync(project, { recursive: true });
  const filler = 'assistant/tool filler ' + 'x'.repeat(fillerBytes);

  for (let dayIndex = 0; dayIndex < days; dayIndex++) {
    for (let sessionIndex = 0; sessionIndex < sessionsPerDay; sessionIndex++) {
      const timestamp = new Date(NOW - dayIndex * DAY - sessionIndex * 1000).toISOString();
      const date = timestamp.slice(0, 10);
      const rows = [];
      for (let messageIndex = 0; messageIndex < messagesPerSession; messageIndex++) {
        const text = longUserText
          ? `user ${date} ${messageIndex} ` + 'safe '.repeat(800)
          : `user message ${date} ${sessionIndex} ${messageIndex}${includeSecret ? ' API_KEY=sk-coverage-secret-123456789' : ''}`;
        rows.push(JSON.stringify({
          type: 'user', uuid: `coverage-user-${dayIndex}-${sessionIndex}-${messageIndex}`,
          timestamp: new Date(Date.parse(timestamp) - messageIndex * 1000).toISOString(),
          message: { role: 'user', content: text }
        }));
      }
      if (dayIndex * sessionsPerDay + sessionIndex < largeSessions) {
        for (let line = 0; line < fillerLines; line++) {
          rows.push(JSON.stringify({ type: line % 2 ? 'assistant' : 'tool', uuid: `private-row-${dayIndex}-${sessionIndex}-${line}`, message: { role: line % 2 ? 'assistant' : 'tool', content: filler } }));
        }
      }
      const file = path.join(project, `session-${String(dayIndex).padStart(2, '0')}-${sessionIndex}.jsonl`);
      fs.writeFileSync(file, rows.join('\n') + '\n');
      const mtime = new Date(NOW - dayIndex * 60_000 - sessionIndex);
      fs.utimesSync(file, mtime, mtime);
    }
  }
  return root;
}

export function createEdgeHistory(root) {
  const project = path.join(root, 'edge-project');
  fs.mkdirSync(project, { recursive: true });
  fs.writeFileSync(path.join(project, 'edge.jsonl'), [
    'x'.repeat(256 * 1024 + 20) + '😀',
    JSON.stringify({ type: 'user', uuid: 'edge-valid', timestamp: COVERAGE_NOW, message: { role: 'user', content: 'after oversized UTF8 line' } })
  ].join('\n') + '\n');
  return root;
}

export function createUnicodeHistory(root) {
  const project = path.join(root, 'unicode-project');
  fs.mkdirSync(project, { recursive: true });
  const prefix = JSON.stringify({ type: 'user', uuid: 'unicode-valid', timestamp: COVERAGE_NOW, message: { role: 'user', content: '' } });
  const pad = 'ab '.repeat(Math.ceil((65535 - Buffer.byteLength(prefix) + 2) / 3)).slice(0, 65535 - Buffer.byteLength(prefix) + 2);
  const row = JSON.stringify({ type: 'user', uuid: 'unicode-valid', timestamp: COVERAGE_NOW, message: { role: 'user', content: pad + '😀' } });
  fs.writeFileSync(path.join(project, 'unicode.jsonl'), row + '\n');
  return root;
}

export function createUnterminatedOversizedHistory(root) {
  const project = path.join(root, 'unterminated-project');
  fs.mkdirSync(project, { recursive: true });
  fs.writeFileSync(path.join(project, 'unterminated.jsonl'), 'x'.repeat(256 * 1024 + 20));
  return root;
}

export function createInventoryHistory(root, count = 5001) {
  const project = path.join(root, 'inventory-project');
  fs.mkdirSync(project, { recursive: true });
  for (let index = 0; index < count; index++) {
    fs.writeFileSync(path.join(project, `session-${String(index).padStart(5, '0')}.jsonl`), '');
  }
  return root;
}

export const COVERAGE_NOW = '2026-10-06T12:00:00Z';
export const COVERAGE_DATES = Array.from({ length: 30 }, (_, index) =>
  new Date(NOW - index * DAY).toISOString().slice(0, 10)
).sort();
