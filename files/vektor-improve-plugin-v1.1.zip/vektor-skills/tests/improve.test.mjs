import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { collect, render, mask } from '../plugins/session-review/scripts/improve.mjs';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const FIXTURE = path.join(ROOT, 'tests', 'fixtures', 'history');
const TMP = path.join(ROOT, '.tmp', 'improve-tests');
const NOW = '2026-10-06T12:00:00Z';
assert.equal(path.relative(ROOT, TMP).startsWith('..'), false, 'test output must stay inside repository');

function reset() {
  fs.rmSync(TMP, { recursive: true, force: true });
  fs.mkdirSync(TMP, { recursive: true, mode: 0o700 });
}
function runCollect(name, options = {}) {
  const out = path.join(TMP, name);
  return { out, result: collect({ history: FIXTURE, now: NOW, out, ...options }) };
}
function readJson(file) { return JSON.parse(fs.readFileSync(file, 'utf8')); }
function writeFindings(run, findings) { fs.writeFileSync(path.join(run, 'findings.json'), JSON.stringify(findings)); }

test.beforeEach(reset);
test.after(() => fs.rmSync(TMP, { recursive: true, force: true }));

test('collects an exact bounded sample and excludes non-user, malformed, duplicate, old, and future rows', () => {
  const { out, result } = runCollect('basic');
  assert.equal(result.stats.candidateFiles, 3);
  assert.equal(result.stats.filesRead, 3);
  assert.equal(result.stats.sessionsAnalyzed, 2);
  assert.equal(result.stats.userMessages, 7);
  assert.equal(result.stats.malformedLines, 1);
  assert.equal(result.stats.duplicateMessages, 1);
  assert.equal(result.stats.outsideWindow, 2);
  assert.deepEqual(result.range, { first: '2026-09-10T09:00:00.000Z', last: '2026-10-01T10:00:00.000Z' });
  const evidence = readJson(path.join(out, 'evidence.json'));
  assert.equal(evidence.window.from, '2026-09-06T12:00:00.000Z');
  assert.equal(evidence.window.to, '2026-10-06T12:00:00.000Z');
  assert.ok(evidence.events.every(event => event.date >= evidence.window.from && event.date <= evidence.window.to));
  assert.ok(evidence.events.every(event => !event.text.includes('API_KEY=sk-test-1234567890')));
  assert.ok(evidence.events.every(event => !event.text.includes('sk-test-1234567890')));
  assert.ok(evidence.events.every(event => !event.text.includes('shortpass')));
  assert.ok(evidence.events.every(event => !event.text.includes('super-secret-value')));
  assert.ok(evidence.events.some(event => event.text.includes('[REDACTED]')));
  assert.ok(!JSON.stringify(evidence).includes('0123456789abcdef0123456789abcdef'));
});

test('caps retained sessions while scanning all files for eligible dates', () => {
  const history = path.join(TMP, 'mtime-history');
  for (const project of fs.readdirSync(FIXTURE)) {
    const sourceDir = path.join(FIXTURE, project);
    const targetDir = path.join(history, project);
    fs.mkdirSync(targetDir, { recursive: true });
    for (const file of fs.readdirSync(sourceDir)) fs.copyFileSync(path.join(sourceDir, file), path.join(targetDir, file));
  }
  const old = new Date('2026-09-01T00:00:00Z');
  const fresh = new Date('2026-10-05T00:00:00Z');
  fs.utimesSync(path.join(history, 'project-alpha', 'session-alpha.jsonl'), old, old);
  fs.utimesSync(path.join(history, 'project-alpha', 'session-old.jsonl'), old, old);
  fs.utimesSync(path.join(history, 'project-beta', 'session-beta.jsonl'), fresh, fresh);
  const out = path.join(TMP, 'cap');
  const result = collect({ history, now: NOW, out, 'max-sessions': '1' });
  assert.equal(result.stats.candidateFiles, 3);
  assert.equal(result.stats.filesRead, 3);
  assert.equal(result.stats.sessionCapReached, true);
  assert.equal(readJson(path.join(out, 'evidence.json')).events.length, 5);
});

test('render validates synthetic model findings, ranks by count, masks planted secrets, and stages only top three drafts', () => {
  const { out } = runCollect('render');
  const evidence = readJson(path.join(out, 'evidence.json'));
  const ids = evidence.events.map(event => event.id);
  const findings = {
    schemaVersion: 1,
    wrongs: [{ title: 'Repeated correction password=shortpass', reason: 'The same correction repeats with sk-test-1234567890.', evidence: ids.slice(0, 2) }],
    skills: [1, 2, 3, 4].map((n, i) => ({
      title: `Routine ${n}`, reason: `Draft includes SECRET_VALUE=super-secret-value and hex 0123456789abcdef0123456789abcdef.`,
      kind: 'routine', evidence: [ids.slice(0, 3), ids.slice(1, 4), ids.slice(2, 5), ids.slice(3, 6)][i],
      draft: { name: `draft-${n}`, description: 'Use API_KEY=sk-test-1234567890 safely.', instructions: 'Never print TOKEN=secret-value. -----BEGIN PRIVATE KEY----- abc -----END PRIVATE KEY-----' }
    })),
    rules: [{ title: 'Local rule', reason: 'Keep evidence local.', evidence: ids.slice(0, 2), line: 'Keep API_KEY=sk-test-1234567890 out of reports.', scope: 'all sessions' }]
  };
  writeFindings(out, findings);
  const rendered = render({ run: out });
  assert.equal(rendered.drafts.length, 3);
  assert.deepEqual(new Set(rendered.drafts), new Set(['draft-1', 'draft-2', 'draft-4']));
  assert.equal(fs.existsSync(path.join(out, 'STAGING', 'draft-3')), false);
  const report = fs.readFileSync(path.join(out, 'report.md'), 'utf8');
  assert.match(report, /what keeps going wrong/);
  assert.match(report, /skills you are missing/);
  assert.match(report, /lines to add to CLAUDE\.md/);
  for (const secret of ['sk-test-1234567890', 'super-secret-value', '0123456789abcdef0123456789abcdef', 'secret-value']) assert.equal(report.includes(secret), false, secret);
  for (const name of rendered.drafts) {
    const draft = fs.readFileSync(path.join(out, 'STAGING', name, 'SKILL.md'), 'utf8');
    assert.equal(draft.includes('sk-test-1234567890'), false);
    assert.equal(draft.includes('super-secret-value'), false);
    assert.equal(draft.includes('secret-value'), false);
  }
  assert.throws(() => render({ run: out }), /already exists/);
});

test('rejects output traversal and symlinks, and never emits raw secret-shaped values', t => {
  assert.throws(() => collect({ history: FIXTURE, now: NOW, out: path.join(ROOT, '..', 'outside') }), /inside the current workspace/);
  assert.equal(mask('Bearer abcdefghijklmnopqrstuvwxyz123456').includes('Bearer abcdef'), false);
  assert.equal(mask('TOKEN=short').includes('TOKEN=short'), false);
  assert.equal(mask('-----BEGIN RSA PRIVATE KEY-----\nsecret\n-----END RSA PRIVATE KEY-----').includes('secret'), false);
  const target = path.join(TMP, 'real-output');
  const link = path.join(TMP, 'output-link');
  fs.mkdirSync(target);
  try { fs.symlinkSync(target, link, 'junction'); } catch { t.skip('symlink creation unavailable on this Windows account'); return; }
  assert.throws(() => collect({ history: FIXTURE, now: NOW, out: link }), /Symlinks/);
});

test('handles missing and empty history without reading the real home history', () => {
  const missing = runCollect('missing', { history: path.join(TMP, 'does-not-exist') });
  assert.equal(missing.result.stats.historyMissing, true);
  assert.equal(missing.result.stats.userMessages, 0);
  const emptyHistory = path.join(TMP, 'empty-history');
  fs.mkdirSync(emptyHistory);
  const empty = runCollect('empty', { history: emptyHistory });
  assert.equal(empty.result.stats.historyMissing, false);
  assert.equal(empty.result.stats.candidateFiles, 0);
  assert.equal(empty.result.stats.sessionsAnalyzed, 0);
  assert.throws(() => collect({ history: FIXTURE, now: 'not-a-date', out: path.join(TMP, 'invalid') }), /ISO timestamp/);
});

test('includes exact cutoff endpoints, converts timezone offsets, and excludes just-outside/future rows', () => {
  const history = path.join(TMP, 'boundary-history', 'p');
  fs.mkdirSync(history, { recursive: true });
  const rows = [
    ['at-cutoff', '2026-09-06T12:00:00Z', 'At inclusive cutoff.'],
    ['offset', '2026-09-06T14:00:00+02:00', 'Same instant with offset.'],
    ['before', '2026-09-06T11:59:59Z', 'One second too old.'],
    ['future', '2026-10-06T12:00:01Z', 'One second in the future.']
  ].map(([uuid, timestamp, content]) => JSON.stringify({ type: 'user', uuid, timestamp, message: { role: 'user', content } })).join('\n');
  fs.writeFileSync(path.join(history, 'boundary.jsonl'), `${rows}\n`);
  const out = path.join(TMP, 'boundary-out');
  const result = collect({ history: path.join(TMP, 'boundary-history'), now: NOW, out });
  const evidence = readJson(path.join(out, 'evidence.json'));
  assert.equal(result.stats.userMessages, 2);
  assert.equal(result.stats.outsideWindow, 2);
  assert.deepEqual(evidence.events.map(event => event.date).sort(), ['2026-09-06T12:00:00.000Z', '2026-09-06T12:00:00.000Z']);
});

test('redacts a long base64-like secret and truncates oversized user text', () => {
  const history = path.join(TMP, 'redaction-history', 'p');
  fs.mkdirSync(history, { recursive: true });
  const base64 = 'QWxhZGRpbjpvcGVuIHNlc2FtZQ=='.repeat(3);
  const long = 'safe '.repeat(1200);
  fs.writeFileSync(path.join(history, 'redaction.jsonl'), [
    { type: 'user', uuid: 'long-secret', timestamp: NOW, message: { role: 'user', content: `credential ${base64}` } },
    { type: 'user', uuid: 'long-text', timestamp: '2026-10-01T00:00:00Z', message: { role: 'user', content: long } }
  ].map(JSON.stringify).join('\n') + '\n');
  const out = path.join(TMP, 'redaction-out');
  const result = collect({ history: path.join(TMP, 'redaction-history'), now: NOW, out });
  const evidence = readJson(path.join(out, 'evidence.json'));
  assert.equal(result.stats.textTruncated, 1);
  assert.ok(evidence.events.every(event => !event.text.includes(base64)));
  assert.ok(evidence.events.some(event => event.truncated));
});

test('requires re-explained skills to span sessions, validates exact quotes, and rejects unsafe drafts before writing', () => {
  const { out } = runCollect('validation');
  const evidence = readJson(path.join(out, 'evidence.json'));
  const ids = evidence.events.map(event => event.id);
  const base = { schemaVersion: 1, wrongs: [], rules: [] };
  const bad = finding => {
    writeFindings(out, { ...base, skills: [finding] });
    assert.throws(() => render({ run: out }));
    assert.equal(fs.existsSync(path.join(out, 'report.md')), false);
    assert.equal(fs.existsSync(path.join(out, 'STAGING')), false);
  };
  bad({ title: 'Same session', reason: 'Repeated task.', kind: 'reexplained-task', evidence: ids.slice(0, 2), draft: { name: 'same-session', description: 'A draft', instructions: 'Instructions' } });
  bad({ title: 'Fake quote', reason: 'Repeated task.', kind: 'reexplained-task', evidence: [ids[0], ids.at(-1)], quotes: { [ids[0]]: 'not present in event' }, draft: { name: 'fake-quote', description: 'A draft', instructions: 'Instructions' } });
  bad({ title: 'Unsafe draft', reason: 'Repeated task.', kind: 'reexplained-task', evidence: [ids[0], ids.at(-1)], draft: { name: '../escape', description: 'A draft', instructions: 'Instructions' } });
  bad({ title: 'Secret-shaped draft', reason: 'Repeated task.', kind: 'reexplained-task', evidence: [ids[0], ids.at(-1)], draft: { name: 'sk-test-1234567890', description: 'A draft', instructions: 'Instructions' } });
  const validRun = runCollect('valid-quote');
  const validEvidence = readJson(path.join(validRun.out, 'evidence.json'));
  const validIds = validEvidence.events.map(event => event.id);
  writeFindings(validRun.out, { ...base, skills: [{ title: 'Cross session', reason: 'Repeated task.', kind: 'reexplained-task', evidence: [validIds[0], validIds.at(-1)], quotes: { [validIds[0]]: validEvidence.events.find(event => event.id === validIds[0]).text.slice(0, 12) }, draft: { name: 'cross-session', description: 'A draft', instructions: 'Instructions' } }] });
  assert.deepEqual(render(validRun.out ? { run: validRun.out } : {} ).drafts, ['cross-session']);
});

test('rejects duplicate evidence IDs, missing IDs, and routines with fewer than three occurrences', () => {
  const { out } = runCollect('invalid-findings');
  const evidence = readJson(path.join(out, 'evidence.json'));
  const [a, b, c] = evidence.events.map(event => event.id);
  for (const item of [
    { title: 'Duplicate IDs', reason: 'x', evidence: [a, a], kind: 'routine', draft: { name: 'dup', description: 'x', instructions: 'x' } },
    { title: 'Missing ID', reason: 'x', evidence: [a, 'e9999'], kind: 'routine', draft: { name: 'missing', description: 'x', instructions: 'x' } },
    { title: 'Too few', reason: 'x', evidence: [a, b], kind: 'routine', draft: { name: 'few', description: 'x', instructions: 'x' } }
  ]) {
    writeFindings(out, { schemaVersion: 1, wrongs: [], skills: [item], rules: [] });
    assert.throws(() => render({ run: out }));
    assert.equal(fs.existsSync(path.join(out, 'STAGING')), false);
  }
  assert.ok(c);
});

test('streams large files and counts oversized lines while retaining valid events', () => {
  const history = path.join(TMP, 'limits-history', 'p');
  fs.mkdirSync(history, { recursive: true });
  fs.writeFileSync(path.join(history, 'valid.jsonl'), JSON.stringify({ type: 'user', uuid: 'valid', timestamp: NOW, message: { role: 'user', content: 'valid event' } }) + '\n' + 'x'.repeat(256 * 1024 + 1) + '\n');
  fs.writeFileSync(path.join(history, 'oversized.jsonl'), 'x');
  fs.truncateSync(path.join(history, 'oversized.jsonl'), 16 * 1024 * 1024 + 1);
  const out = path.join(TMP, 'limits-out');
  const result = collect({ history: path.join(TMP, 'limits-history'), now: NOW, out });
  assert.equal(result.stats.oversizedLines, 2);
  assert.equal(result.stats.oversizedFiles, 0);
  assert.equal(result.stats.userMessages, 1);
});

test('keeps marketplace/plugin manifests and the discoverable skill frontmatter aligned', () => {
  execFileSync(process.execPath, ['scripts/generate.mjs', '--check'], { cwd: ROOT, stdio: 'pipe' });
  const marketplace = readJson(path.join(ROOT, '.claude-plugin', 'marketplace.json'));
  const pluginEntry = marketplace.plugins.find(item => item.name === 'vektor');
  assert.ok(pluginEntry);
  assert.equal(pluginEntry.source, './plugins/session-review');
  assert.equal(pluginEntry.license, 'MIT');
  const plugin = readJson(path.join(ROOT, 'plugins', 'session-review', '.claude-plugin', 'plugin.json'));
  assert.equal(plugin.name, 'vektor');
  const skill = fs.readFileSync(path.join(ROOT, 'plugins', 'session-review', 'skills', 'improve', 'SKILL.md'), 'utf8');
  const frontmatter = skill.match(/^---\n([\s\S]*?)\n---/);
  assert.ok(frontmatter);
  assert.match(frontmatter[1], /^name:\s*improve$/m);
  assert.match(frontmatter[1], /^description:\s*\S/m);
});

test('renders an empty findings result with an empty staging folder', () => {
  const { out } = runCollect('empty-report');
  writeFindings(out, { schemaVersion: 1, wrongs: [], skills: [], rules: [] });
  const rendered = render({ run: out });
  assert.deepEqual(rendered.drafts, []);
  assert.match(fs.readFileSync(path.join(out, 'report.md'), 'utf8'), /No supported finding in this sample/);
  assert.deepEqual(fs.readdirSync(path.join(out, 'STAGING')), []);
});

test('collects a genuine three-session routine and stages its contextual draft only', () => {
  const out = path.join(TMP, 'routine-integration');
  collect({ history: path.join(ROOT, 'tests', 'fixtures', 'routines-history'), now: NOW, out });
  const evidence = readJson(path.join(out, 'evidence.json'));
  const routineEvents = evidence.events.filter(event => event.text.includes('Run release routine'));
  assert.equal(routineEvents.length, 3);
  assert.equal(new Set(routineEvents.map(event => event.session)).size, 3);
  const correctionEvents = evidence.events.filter(event => event.text.includes('wrong repo'));
  assert.equal(correctionEvents.length, 3);
  writeFindings(out, {
    schemaVersion: 1,
    wrongs: [{ title: 'Wrong repository selected', reason: 'The same correction recurs.', evidence: correctionEvents.map(event => event.id) }],
    skills: [{ title: 'Release review routine', reason: 'The three-step routine recurs across three sessions.', kind: 'routine', evidence: routineEvents.map(event => event.id), quotes: Object.fromEntries(routineEvents.map(event => [event.id, 'Run release routine'])), draft: { name: 'release-review', description: 'Run the recurring release review.', instructions: 'Render, inspect, and record the result for review.' } }],
    rules: []
  });
  const rendered = render({ run: out });
  assert.deepEqual(rendered.drafts, ['release-review']);
  assert.equal(fs.existsSync(path.join(out, 'STAGING', 'release-review', 'SKILL.md')), true);
  const allFiles = [];
  const walk = dir => { for (const entry of fs.readdirSync(dir, { withFileTypes: true })) { const target = path.join(dir, entry.name); if (entry.isDirectory()) walk(target); else allFiles.push(path.relative(out, target).replaceAll('\\', '/')); } };
  walk(out);
  assert.deepEqual(new Set(allFiles), new Set(['evidence.json', 'findings.example.json', 'findings.json', 'report.md', 'STAGING/release-review/SKILL.md']));
});

test('keeps ordinary prose intact while masking a multi-word password assignment', () => {
  assert.equal(mask('Steps: check inputs'), 'Steps: check inputs');
  assert.equal(mask('PASSWORD=two word fake value'), 'PASSWORD=[REDACTED]');
});

test('enforces the evidence text budget and event cap while retaining newest events', () => {
  const makeHistory = (name, count, width) => {
    const history = path.join(TMP, name, 'p');
    fs.mkdirSync(history, { recursive: true });
    const rows = [];
    for (let index = 0; index < count; index++) {
      const timestamp = new Date(Date.parse('2026-09-07T00:00:00Z') + index * 60000).toISOString();
      rows.push(JSON.stringify({ type: 'user', uuid: `${name}-${index}`, timestamp, message: { role: 'user', content: `event-${index} ${'safe '.repeat(Math.floor(width / 5))}` } }));
    }
    fs.writeFileSync(path.join(history, `${name}.jsonl`), `${rows.join('\n')}\n`);
    return path.join(TMP, name);
  };
  const budgetOut = path.join(TMP, 'budget-out');
  const budget = collect({ history: makeHistory('budget-history', 40, 3990), now: NOW, out: budgetOut });
  const budgetEvidence = readJson(path.join(budgetOut, 'evidence.json'));
  assert.equal(budget.stats.textBudgetReached, true);
  assert.ok(budgetEvidence.events.length < 40);
  assert.match(budgetEvidence.events[0].text, /event-39/);
  assert.ok(budgetEvidence.events.reduce((sum, event) => sum + event.text.length, 0) <= 120000);

  const capOut = path.join(TMP, 'event-cap-out');
  const cap = collect({ history: makeHistory('event-cap-history', 510, 10), now: NOW, out: capOut });
  const capEvidence = readJson(path.join(capOut, 'evidence.json'));
  assert.equal(cap.stats.eventCapReached, true);
  assert.equal(capEvidence.events.length, 500);
  assert.match(capEvidence.events[0].text, /event-509/);
  assert.match(capEvidence.events.at(-1).text, /event-10/);
  assert.equal(cap.stats.userMessages, 500);
});
