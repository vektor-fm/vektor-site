import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { collect, render } from '../plugins/session-review/scripts/improve.mjs';
import { createCoverageHistory, createEdgeHistory, createInventoryHistory, createUnicodeHistory, createUnterminatedOversizedHistory, COVERAGE_DATES, COVERAGE_NOW } from './fixtures/coverage-history.mjs';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const TMP = path.join(ROOT, '.tmp', 'coverage-tests');
const FULL_DATES = Array.from({ length: 31 }, (_, index) => new Date(Date.parse(COVERAGE_NOW) - index * 86_400_000).toISOString().slice(0, 10)).sort();
const readJson = file => JSON.parse(fs.readFileSync(file, 'utf8'));
const writeEmptyFindings = out => fs.writeFileSync(path.join(out, 'findings.json'), JSON.stringify({ schemaVersion: 1, wrongs: [], skills: [], rules: [] }));
const reset = () => { fs.rmSync(TMP, { recursive: true, force: true }); fs.mkdirSync(TMP, { recursive: true, mode: 0o700 }); };
test.beforeEach(reset);
test.after(() => fs.rmSync(TMP, { recursive: true, force: true }));

test('samples retained user messages across the complete window despite newest large files', () => {
  const history = createCoverageHistory(path.join(TMP, 'history'), { days: 31, sessionsPerDay: 4, includeSecret: true });
  const out = path.join(TMP, 'run');
  const result = collect({ history, now: COVERAGE_NOW, out });
  const evidence = readJson(path.join(out, 'evidence.json'));
  assert.equal(result.stats.candidateFiles, 124);
  assert.equal(result.stats.filesRead, 124);
  assert.equal(result.stats.sessionsAnalyzed, 100);
  assert.equal(result.stats.userMessages, 100);
  assert.equal(result.stats.sessionCapReached, true);
  assert.equal(result.stats.byteCapReached, false);
  assert.equal(result.stats.oversizedFiles, 0);
  assert.equal(result.stats.outsideWindow, 3);
  const expectedBytes = fs.readdirSync(path.join(history, 'coverage-project'))
    .map(file => fs.statSync(path.join(history, 'coverage-project', file)).size)
    .reduce((sum, size) => sum + size, 0);
  assert.equal(result.stats.bytesRead, expectedBytes);
  assert.deepEqual(evidence.events.map(event => event.date.slice(0, 10)).filter((date, index, dates) => dates.indexOf(date) === index).sort(), FULL_DATES);
  assert.equal(evidence.range.first, '2026-09-06T12:00:00.000Z');
  assert.equal(evidence.range.last, '2026-10-06T12:00:00.000Z');
  assert.ok(evidence.events.every(event => event.text.startsWith('user message ')));
  assert.ok(evidence.events.every(event => event.text.includes('[REDACTED]')));
  assert.ok(result.stats.bytesRead > 64 * 1024 * 1024);
  assert.equal(JSON.stringify(evidence).includes('assistant/tool filler'), false);
  assert.equal(JSON.stringify(evidence).includes('private-row-'), false);
  assert.equal(JSON.stringify(evidence).includes('coverage-user-'), false);
  assert.equal(JSON.stringify(evidence).includes('sk-coverage-secret-123456789'), false);
  assert.equal(JSON.stringify(evidence).includes(history), false);

  const secondOut = path.join(TMP, 'run-31');
  const second = collect({ history, now: COVERAGE_NOW, out: secondOut, 'max-sessions': '31' });
  const secondEvidence = readJson(path.join(secondOut, 'evidence.json'));
  assert.equal(second.stats.sessionsAnalyzed, 31);
  assert.equal(second.stats.userMessages, 31);
  assert.equal(second.stats.bytesRead, expectedBytes);
  assert.deepEqual(secondEvidence.events.map(event => event.date.slice(0, 10)).filter((date, index, dates) => dates.indexOf(date) === index).sort(), FULL_DATES);
  assert.equal(secondEvidence.range.first, '2026-09-06T12:00:00.000Z');
  assert.equal(secondEvidence.range.last, '2026-10-06T12:00:00.000Z');
  assert.deepEqual(secondEvidence.events.map(event => event.text).sort(), FULL_DATES.map(date => `user message ${date} 0 0 API_KEY=[REDACTED]`).sort());
  assert.deepEqual(secondEvidence.coverage.unrepresentedDates, []);
});

test('retained event cap is reported while messages remain spread across dates', () => {
  const history = createCoverageHistory(path.join(TMP, 'history'), { messagesPerSession: 25, fillerLines: 0, largeSessions: 0 });
  const out = path.join(TMP, 'run');
  const result = collect({ history, now: COVERAGE_NOW, out, 'max-sessions': '30' });
  const evidence = readJson(path.join(out, 'evidence.json'));
  assert.equal(result.stats.userMessages, 500);
  assert.equal(result.stats.textBudgetReached, false);
  assert.equal(result.stats.eventCapReached, true);
  assert.ok(evidence.events.every(event => event.text.length <= 4000));
  assert.ok(evidence.events.every(event => event.date >= evidence.window.from && event.date <= evidence.window.to));
  assert.deepEqual(evidence.coverage.representedDates, COVERAGE_DATES);
  assert.deepEqual(evidence.coverage.unrepresentedDates, ['2026-09-06']);
  writeEmptyFindings(out);
  render({ run: out });
  assert.match(fs.readFileSync(path.join(out, 'report.md'), 'utf8'), /"eventCapReached":\s*true/);
});

test('retained text cap is reported independently of the event cap', () => {
  const history = createCoverageHistory(path.join(TMP, 'history'), { fillerLines: 0, largeSessions: 0, longUserText: true, messagesPerSession: 2 });
  const out = path.join(TMP, 'run');
  const result = collect({ history, now: COVERAGE_NOW, out, 'max-sessions': '30' });
  const evidence = readJson(path.join(out, 'evidence.json'));
  assert.equal(result.stats.userMessages, 30);
  assert.equal(result.stats.textBudgetReached, true);
  assert.equal(result.stats.eventCapReached, false);
  assert.ok(evidence.events.every(event => event.text.length <= 4000));
  assert.deepEqual(evidence.coverage.representedDates, COVERAGE_DATES);
  assert.equal(evidence.events.reduce((sum, event) => sum + event.text.length, 0), 120000);
  writeEmptyFindings(out);
  render({ run: out });
  assert.match(fs.readFileSync(path.join(out, 'report.md'), 'utf8'), /"textBudgetReached":\s*true/);
});

test('reports both retained-message and text ceilings when the same row hits both', () => {
  const project = path.join(TMP, 'both-caps', 'p');
  fs.mkdirSync(project, { recursive: true });
  const rows = Array.from({ length: 501 }, (_, index) => JSON.stringify({
    type: 'user', uuid: `both-${index}`,
    timestamp: new Date(Date.parse(COVERAGE_NOW) - index * 1000).toISOString(),
    message: { role: 'user', content: 'safe '.repeat(48) }
  }));
  fs.writeFileSync(path.join(project, 'both.jsonl'), rows.join('\n'));
  const out = path.join(TMP, 'both-run');
  const { stats } = collect({ history: path.dirname(project), now: COVERAGE_NOW, out });
  assert.equal(stats.userMessages, 500);
  assert.equal(stats.eventCapReached, true);
  assert.equal(stats.textBudgetReached, true);
  writeEmptyFindings(out);
  render({ run: out });
  const report = fs.readFileSync(path.join(out, 'report.md'), 'utf8');
  assert.match(report, /"eventCapReached":\s*true/);
  assert.match(report, /"textBudgetReached":\s*true/);
});

test('session cap retains representatives from all dates when many sessions compete', () => {
  const history = createCoverageHistory(path.join(TMP, 'history'), { days: 30, sessionsPerDay: 4, fillerLines: 0, largeSessions: 0 });
  const out = path.join(TMP, 'run');
  const result = collect({ history, now: COVERAGE_NOW, out, 'max-sessions': '30' });
  const evidence = readJson(path.join(out, 'evidence.json'));
  assert.equal(result.stats.candidateFiles, 120);
  assert.equal(result.stats.sessionsAnalyzed, 30);
  assert.equal(result.stats.userMessages, 30);
  assert.equal(result.stats.sessionCapReached, true);
  assert.deepEqual(evidence.coverage.representedDates, COVERAGE_DATES);
});

test('a two-session cap still chooses both ends of the date window', () => {
  const history = createCoverageHistory(path.join(TMP, 'history'), { days: 30, sessionsPerDay: 4, fillerLines: 0, largeSessions: 0 });
  const out = path.join(TMP, 'run');
  const result = collect({ history, now: COVERAGE_NOW, out, 'max-sessions': '2' });
  const evidence = readJson(path.join(out, 'evidence.json'));
  assert.equal(result.stats.sessionsAnalyzed, 2);
  assert.equal(result.stats.sessionCapReached, true);
  assert.equal(evidence.coverage.representedDates.length, 2);
  assert.deepEqual(evidence.coverage.representedDates, [COVERAGE_DATES[0], COVERAGE_DATES.at(-1)]);
});

test('byte scan cap reports the missing dates in the rendered report', () => {
  const history = createCoverageHistory(path.join(TMP, 'history'), { fillerLines: 40 });
  const out = path.join(TMP, 'run');
  const result = collect({ history, now: COVERAGE_NOW, out, 'max-sessions': '30', 'max-scan-bytes': '1048576' });
  const evidence = readJson(path.join(out, 'evidence.json'));
  assert.equal(result.stats.byteCapReached, true);
  assert.equal(evidence.coverage.scanComplete, false);
  assert.ok(evidence.coverage.unrepresentedDates.length > 0);
  fs.writeFileSync(path.join(out, 'findings.json'), JSON.stringify({ schemaVersion: 1, wrongs: [], skills: [], rules: [] }));
  render({ run: out });
  const report = fs.readFileSync(path.join(out, 'report.md'), 'utf8');
  assert.match(report.split('\n')[2], /Observed user-message range:.*shorter.*because.*scan safety limit/);
  assert.equal(result.stats.bytesRead, 1048576);
  assert.match(report, /not covered|unrepresented/i);
  for (const date of evidence.coverage.unrepresentedDates) assert.match(report, new RegExp(date));
});

test('a byte cap in the middle of a line creates no phantom malformed row', () => {
  const history = createCoverageHistory(path.join(TMP, 'history'), { fillerLines: 10, largeSessions: 1 });
  const out = path.join(TMP, 'run');
  const result = collect({ history, now: COVERAGE_NOW, out, 'max-scan-bytes': '150000' });
  assert.equal(result.stats.byteCapReached, true);
  assert.equal(result.stats.userMessages, 1);
  assert.equal(result.stats.malformedLines, 0);
});

test('oversized UTF8 line is skipped and a following valid user row survives', () => {
  const history = createEdgeHistory(path.join(TMP, 'history'));
  const out = path.join(TMP, 'run');
  const result = collect({ history, now: COVERAGE_NOW, out });
  const evidence = readJson(path.join(out, 'evidence.json'));
  assert.equal(result.stats.oversizedLines, 1);
  assert.equal(result.stats.malformedLines, 0);
  assert.equal(result.stats.userMessages, 1);
  assert.equal(evidence.events[0].text, 'after oversized UTF8 line');
});

test('a UTF8 code point split across a scan chunk is retained exactly', () => {
  const history = createUnicodeHistory(path.join(TMP, 'history'));
  const out = path.join(TMP, 'run');
  const result = collect({ history, now: COVERAGE_NOW, out });
  const evidence = readJson(path.join(out, 'evidence.json'));
  assert.equal(result.stats.userMessages, 1);
  assert.equal(result.stats.malformedLines, 0);
  assert.equal(evidence.events[0].text.startsWith('ab '), true);
  assert.equal(result.stats.textTruncated, 1);
});

test('an unterminated oversized final line is counted without a phantom parse', () => {
  const history = createUnterminatedOversizedHistory(path.join(TMP, 'history'));
  const out = path.join(TMP, 'run');
  const result = collect({ history, now: COVERAGE_NOW, out });
  assert.equal(result.stats.oversizedLines, 1);
  assert.equal(result.stats.malformedLines, 0);
  assert.equal(result.stats.userMessages, 0);
});

test('inventory cap is reported for more than 5000 candidate files', () => {
  const history = createInventoryHistory(path.join(TMP, 'history'));
  const out = path.join(TMP, 'run');
  const result = collect({ history, now: COVERAGE_NOW, out });
  const evidence = readJson(path.join(out, 'evidence.json'));
  assert.equal(result.stats.candidateFiles, 5000);
  assert.equal(result.stats.inventoryCapReached, true);
  assert.equal(evidence.coverage.scanComplete, false);
  writeEmptyFindings(out);
  render({ run: out });
  assert.match(fs.readFileSync(path.join(out, 'report.md'), 'utf8'), /"inventoryCapReached":\s*true/);
});
