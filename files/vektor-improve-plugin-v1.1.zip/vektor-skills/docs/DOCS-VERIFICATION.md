# Documentation verification

Checked 2026-10-06 against current official Anthropic Claude Code documentation. This records documentation checks, not a live plugin installation. Source files were authored locally; no official plugin CLI, account configuration or real history was used.

| Contract | Official source | Implementation / status |
| --- | --- | --- |
| Plugin root has `.claude-plugin/plugin.json`; skills live beside that directory, not inside it | [Create a plugin](https://code.claude.com/docs/en/plugins/create), “Create your first plugin” and “Plugin layout” | Implemented under `plugins/session-review/` |
| Plugin name namespaces skills; each skill has YAML frontmatter and a SKILL.md directory | [Create a plugin](https://code.claude.com/docs/en/plugins/create), first skill example; [Skills](https://code.claude.com/docs/en/skills), frontmatter reference | `name` and `description` used; slash spelling in generated README is expected, not observed |
| Marketplace manifest requires name, owner and plugin entries with local relative sources | [Create a marketplace](https://code.claude.com/docs/en/plugin-marketplaces), “Create the marketplace file” | Root `.claude-plugin/marketplace.json` points to `./plugins/session-review` |
| Add a repository marketplace, then install plugin@marketplace | [Install and manage plugins](https://code.claude.com/docs/en/plugins/install); [Marketplaces](https://code.claude.com/docs/en/plugin-marketplaces) | Exact provisional commands generated in README; remote installation not run |
| Supporting scripts and a skill-directory substitution are supported | [Skills](https://code.claude.com/docs/en/skills), supporting files and advanced patterns | Entry skill resolves the helper using its actual directory; no hooks/MCP server needed |
| Anthropic skill-creator can draft/evaluate skills | [Skills](https://code.claude.com/docs/en/skills), skill-creator guidance | Handoff only if already available; no automatic install; text-only drafting restriction still requires a real session check |
| Native Claude Code requires connectivity; Node is not a guaranteed prerequisite | [Advanced setup](https://code.claude.com/docs/en/getting-started), system requirements | Explicit Node.js >=20 requirement; zero npm dependencies; README distinguishes local helper from service-backed model judgment |
| At startup, older session data is removed according to cleanupPeriodDays, default 30 days | [Costs](https://code.claude.com/docs/en/costs), “Analyze your usage patterns” | README/skill/report warn and give a manual 90-day example; no setting is read or changed |
| Settings are configured in JSON files including `~/.claude/settings.json` | [Settings](https://code.claude.com/docs/en/settings) | Documented manual merge only |

The separate full [settings reference](https://code.claude.com/docs/en/settings-reference.md) could not be retrieved directly by the tools used (page-size/TLS limitations). The default and startup retention statement were verified directly on the official costs page instead. No claim is made here about minimum/zero-value behavior.

The plugin validation command documented by Anthropic is `claude plugin validate ./plugins/session-review`. It was deliberately not executed: the build scope forbids changing anything under the founder's real Claude configuration, and invoking the installed client can initialize state. The repository's deterministic checks cover manifest shape, source paths, generated identity consistency and frontmatter; they do not substitute for the official CLI or an installed run.

JSONL support is intentionally defensive: expected timestamped user-message shapes are exercised with synthetic fixtures. No real line, including its keys/types, was inspected. Actual history compatibility remains a founder-run acceptance item.

The source spec mentioned an earlier film date. The current build request takes precedence: film NO.064 is scheduled for 2026-10-08; this repository makes no publishing or scheduling changes.
